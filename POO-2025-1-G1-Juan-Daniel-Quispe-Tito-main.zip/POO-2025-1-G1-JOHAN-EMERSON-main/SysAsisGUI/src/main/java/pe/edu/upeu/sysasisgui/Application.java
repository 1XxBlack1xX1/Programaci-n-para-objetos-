package pe.edu.upeu.sysasisgui;

public class Application {
    public static void main(String[] args) {
        SysAsisGuiApplication.main(args);
    }
}
