import java.util.ArrayList;
import java.util.List;

public class MainAsistencia {

    List<Persona> personas;

    public void cargarPersonas() {
        personas=new ArrayList<>();
        personas.add(new Persona());
    }


    public static void main(String[] args) {

    }
}
