package modelo;

public class Persona {
    public String dni;
    public String nombre;
    public String estado="";

    public Persona(String dni, String nombre) {
        this.dni = dni;
        this.nombre = nombre;
    }



}
